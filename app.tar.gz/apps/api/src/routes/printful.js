import 'dotenv/config';
import express from 'express';
import logger from '../utils/logger.js';

const router = express.Router();

// Helper function to extract image URL from Printful product data
const extractProductImage = (product) => {
  logger.debug(`Extracting image for product: ${product.title || product.id}`);
  
  // Priority 1: Check for images array (most common in Printful API)
  if (product.images && Array.isArray(product.images) && product.images.length > 0) {
    const firstImage = product.images[0];
    logger.debug(`Found image in 'images' array: ${JSON.stringify(firstImage)}`);
    // Handle both object format { src: '...', url: '...' } and string format
    const imageUrl = typeof firstImage === 'string' ? firstImage : (firstImage.src || firstImage.url);
    if (imageUrl) {
      logger.debug(`Extracted imageUrl from images array: ${imageUrl}`);
      return imageUrl;
    }
  }
  
  // Priority 2: Check for product_image field
  if (product.product_image) {
    logger.debug(`Found product_image field: ${JSON.stringify(product.product_image)}`);
    const imageUrl = typeof product.product_image === 'string' ? product.product_image : product.product_image.src;
    if (imageUrl) {
      logger.debug(`Extracted imageUrl from product_image: ${imageUrl}`);
      return imageUrl;
    }
  }
  
  // Priority 3: Check for thumbnail field
  if (product.thumbnail) {
    logger.debug(`Found thumbnail field: ${JSON.stringify(product.thumbnail)}`);
    const imageUrl = typeof product.thumbnail === 'string' ? product.thumbnail : product.thumbnail.src;
    if (imageUrl) {
      logger.debug(`Extracted imageUrl from thumbnail: ${imageUrl}`);
      return imageUrl;
    }
  }
  
  // Priority 4: Check for image field
  if (product.image) {
    logger.debug(`Found image field: ${JSON.stringify(product.image)}`);
    const imageUrl = typeof product.image === 'string' ? product.image : product.image.src;
    if (imageUrl) {
      logger.debug(`Extracted imageUrl from image: ${imageUrl}`);
      return imageUrl;
    }
  }
  
  // Priority 5: Check for variants with images
  if (product.variants && Array.isArray(product.variants) && product.variants.length > 0) {
    const firstVariant = product.variants[0];
    logger.debug(`Checking first variant for images: ${JSON.stringify(firstVariant)}`);
    
    if (firstVariant.images && Array.isArray(firstVariant.images) && firstVariant.images.length > 0) {
      const variantImage = firstVariant.images[0];
      const imageUrl = typeof variantImage === 'string' ? variantImage : (variantImage.src || variantImage.url);
      if (imageUrl) {
        logger.debug(`Extracted imageUrl from variant images: ${imageUrl}`);
        return imageUrl;
      }
    }
  }
  
  logger.warn(`No image found for product: ${product.title || product.id}`);
  return '';
};

// Helper function to format product data with image URL from Printful
const formatProductWithImage = (product) => {
  const imageUrl = extractProductImage(product);
  
  return {
    id: product.id,
    title: product.title,
    description: product.description || '',
    imageUrl: imageUrl,
    image: product.image || '',
    variants: product.variants || [],
    tags: product.tags || [],
    createdAt: product.created || null,
    updatedAt: product.updated || null,
    isPrintful: true,
    // Include original product data for reference
    ...product,
  };
};

// GET /printful/products - Fetch products from user's Printful store
router.get('/products', async (req, res) => {
  const apiKey = process.env.PRINTFUL_API_KEY;

  if (!apiKey) {
    logger.error('PRINTFUL_API_KEY is not configured in environment');
    return res.status(400).json({ error: 'PRINTFUL_API_KEY is not configured' });
  }

  logger.info('Fetching products from user\'s Printful store');

  const response = await fetch('https://api.printful.com/store/products', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
  });

  logger.info(`Printful API response status: ${response.status}`);

  if (!response.ok) {
    logger.error(`Printful API error: ${response.status} ${response.statusText}`);
    throw new Error(`Printful API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  logger.debug(`Full Printful API response: ${JSON.stringify(data, null, 2)}`);
  
  const products = data.result || [];
  
  // Log first product structure for debugging
  if (products.length > 0) {
    logger.info(`First product structure: ${JSON.stringify(products[0], null, 2)}`);
  }
  
  // Format products with extracted image URLs from Printful
  const formattedProducts = products.map(product => formatProductWithImage(product));
  
  logger.info(`Successfully fetched ${formattedProducts.length} products from user's Printful store`);
  
  // Log product names and image URLs to verify
  formattedProducts.forEach((product, index) => {
    logger.info(`Product ${index + 1}: ${product.title} - Image URL: ${product.imageUrl || 'No image found'}`);
  });

  res.json(formattedProducts);
});

// POST /printful/sync - Sync products from user's Printful store (fresh fetch, no caching)
router.post('/sync', async (req, res) => {
  const apiKey = process.env.PRINTFUL_API_KEY;

  if (!apiKey) {
    logger.error('PRINTFUL_API_KEY is not configured in environment');
    return res.status(400).json({ error: 'PRINTFUL_API_KEY is not configured' });
  }

  logger.info('Starting Printful sync - fetching fresh products from user\'s store');
  const syncStartTime = Date.now();

  const response = await fetch('https://api.printful.com/store/products', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
  });

  logger.info(`Printful API response status: ${response.status}`);

  if (!response.ok) {
    logger.error(`Printful API error: ${response.status} ${response.statusText}`);
    throw new Error(`Printful API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  logger.debug(`Full Printful API response: ${JSON.stringify(data, null, 2)}`);
  
  const products = data.result || [];
  
  // Log first product structure for debugging
  if (products.length > 0) {
    logger.info(`First product structure: ${JSON.stringify(products[0], null, 2)}`);
  }
  
  // Format products with extracted image URLs from Printful
  const formattedProducts = products.map(product => formatProductWithImage(product));
  
  const syncDurationMs = Date.now() - syncStartTime;

  logger.info(`Sync complete: ${formattedProducts.length} products fetched from user's store in ${syncDurationMs}ms`);
  
  // Log product names and image URLs to verify
  formattedProducts.forEach((product, index) => {
    logger.info(`Synced Product ${index + 1}: ${product.title} - Image URL: ${product.imageUrl || 'No image found'}`);
  });

  res.json({
    success: true,
    productsCount: formattedProducts.length,
    products: formattedProducts,
    syncedAt: new Date().toISOString(),
    syncDurationMs: syncDurationMs,
  });
});

export default router;