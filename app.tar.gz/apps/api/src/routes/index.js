import { Router } from 'express';
import healthCheck from './health-check.js';
import printfulRouter from './printful.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.use('/printful', printfulRouter);

    return router;
};