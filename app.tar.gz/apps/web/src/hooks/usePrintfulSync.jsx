
import { useState, useCallback } from 'react';
import apiServerClient from '@/lib/apiServerClient.js';
import { useToast } from '@/hooks/use-toast.js';

export const usePrintfulSync = () => {
  const [products, setProducts] = useState([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSynced, setIsSynced] = useState(false);
  const [syncError, setSyncError] = useState(null);
  const [productCount, setProductCount] = useState(0);
  const [syncStatus, setSyncStatus] = useState('idle'); // idle, syncing, success, error
  const { toast } = useToast();

  const normalizeProducts = (rawProducts) => {
    if (!Array.isArray(rawProducts)) return [];
    return rawProducts.map(p => ({
      id: `pf-${p.printfulId || p.id}`,
      title: p.name || p.title,
      subtitle: p.description,
      image: p.image || (p.images && p.images[0]) || '',
      price_in_cents: p.price ? Math.round(p.price * 100) : 0,
      isPrintful: true,
      category: p.category || p.printfulCategory || 'General',
      variants: p.variants && p.variants.length > 0 ? p.variants.map(v => ({
        id: v.id,
        price_in_cents: v.price ? Math.round(v.price * 100) : Math.round((p.price || 0) * 100),
        sale_price_in_cents: null,
        inventory_quantity: 999,
        options: [
          v.size ? { value: String(v.size) } : null,
          v.color ? { value: String(v.color) } : null
        ].filter(Boolean)
      })) : [{
        id: `v-${p.id}`,
        price_in_cents: p.price ? Math.round(p.price * 100) : 0,
        sale_price_in_cents: null,
        inventory_quantity: 999,
        options: []
      }]
    }));
  };

  const syncProducts = useCallback(async () => {
    setIsSyncing(true);
    setSyncStatus('syncing');
    setSyncError(null);
    console.log("[SYNC_START] Starting fresh sync from Printful API...");
    
    try {
      const response = await apiServerClient.fetch('/printful/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || data.message || `HTTP Error ${response.status}: Failed to sync products`);
      }
      
      console.log(`[SYNC_SUCCESS] Received ${data.productsCount} products from Printful.`);
      console.log("[SYNC_COMPLETE] Sync process finished successfully.");
      
      // Clear any cached product data from localStorage to ensure fresh data is used
      try {
        localStorage.removeItem('printful_products');
        localStorage.removeItem('cached_products');
        console.log("[SYNC_CACHE] Cleared local product caches.");
      } catch (e) {
        console.warn("[SYNC_CACHE] Failed to clear localStorage:", e);
      }
      
      const normalized = normalizeProducts(data.products || []);
      setProducts(normalized);
      setProductCount(normalized.length);
      setIsSynced(true);
      setSyncStatus('success');
      
      toast({
        title: "Sync Complete",
        description: `Successfully synced ${data.productsCount} products.`,
      });
      return data;
      
    } catch (err) {
      console.error("[SYNC_ERROR] Error during sync:", err);
      setSyncError(err.message);
      setSyncStatus('error');
      toast({
        title: "Sync Failed",
        description: err.message,
        variant: "destructive",
      });
      return null;
    } finally {
      setIsSyncing(false);
    }
  }, [toast]);

  const getProducts = useCallback(async () => {
    setIsSyncing(true);
    setSyncError(null);
    try {
      console.log("[FETCH_PRODUCTS] Fetching products via GET /printful/products");
      const response = await apiServerClient.fetch('/printful/products');
      
      if (!response.ok) {
        let errorMessage = `HTTP Error ${response.status}`;
        try {
          const errData = await response.json();
          errorMessage = errData.error || errData.message || errorMessage;
        } catch (e) {
          // Ignore JSON parse error if response is not JSON
        }
        throw new Error(errorMessage);
      }
      
      // Backend returns an ARRAY directly for GET /printful/products
      const data = await response.json();
      const productsArray = Array.isArray(data) ? data : [];
      
      console.log(`[FETCH_PRODUCTS] Retrieved ${productsArray.length} products.`);
      
      const normalized = normalizeProducts(productsArray);
      setProducts(normalized);
      setProductCount(normalized.length);
      setIsSynced(true);
      setSyncStatus('success');
      return normalized;
      
    } catch (err) {
      console.error("[FETCH_PRODUCTS] Error:", err);
      setSyncError(err.message);
      setSyncStatus('error');
      toast({
        title: "Fetch Failed",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setIsSyncing(false);
    }
    return [];
  }, [toast]);

  return {
    products,
    isSyncing,
    isLoading: isSyncing,
    isSynced,
    syncError,
    error: syncError,
    productCount,
    syncStatus,
    syncProducts,
    getProducts
  };
};
