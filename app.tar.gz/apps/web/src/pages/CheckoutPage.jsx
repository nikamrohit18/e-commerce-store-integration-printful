
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { useCart } from '@/hooks/useCart.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast.js';
import { formatPriceUSD } from '@/utils/priceFormatter.js';
import { Loader2 } from 'lucide-react';

const CheckoutPage = () => {
  const { cartItems, clearCart } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const calculateTotalCents = () => {
    return cartItems.reduce((sum, item) => {
      const price = item.variant.sale_price_in_cents || item.variant.price_in_cents;
      return sum + (price * item.quantity);
    }, 0);
  };

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: '',
    discountCode: '',
    shippingMethod: 'standard'
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate checkout processing
    setTimeout(() => {
      setLoading(false);
      toast({
        title: 'Order Confirmed!',
        description: 'Your order has been successfully placed.',
      });
      if (clearCart) clearCart();
      navigate('/shop');
    }, 1500);
  };

  if (cartItems.length === 0) {
    return (
      <>
        <Helmet>
          <title>Checkout - LUXE Fashion</title>
          <meta name="description" content="Complete your purchase at LUXE Fashion." />
        </Helmet>

        <div className="min-h-screen flex items-center justify-center bg-background">
          <div className="text-center p-8">
            <h2 className="text-3xl font-bold mb-4 text-foreground tracking-tight">Your cart is empty</h2>
            <p className="text-muted-foreground mb-6">Add some items to your cart to proceed with checkout.</p>
            <Button onClick={() => navigate('/shop')} className="bg-primary text-primary-foreground hover:bg-primary/90">
              Continue Shopping
            </Button>
          </div>
        </div>
      </>
    );
  }

  const subtotal = calculateTotalCents();
  const total = subtotal; // Assuming free shipping for now

  return (
    <>
      <Helmet>
        <title>Checkout - LUXE Fashion</title>
        <meta name="description" content="Complete your purchase at LUXE Fashion." />
      </Helmet>

      <div className="min-h-screen py-12 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-8 text-foreground tracking-tight">Checkout</h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="bg-card rounded-2xl p-6 md:p-8 shadow-sm border border-border">
                <h2 className="text-2xl font-semibold mb-6 text-card-foreground">Shipping Information</h2>
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <Label htmlFor="fullName" className="text-card-foreground">Full Name</Label>
                      <Input
                        id="fullName"
                        name="fullName"
                        type="text"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        required
                        className="text-foreground bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-card-foreground">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="text-foreground bg-background"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address" className="text-card-foreground">Address</Label>
                    <Input
                      id="address"
                      name="address"
                      type="text"
                      value={formData.address}
                      onChange={handleInputChange}
                      required
                      className="text-foreground bg-background"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                    <div className="space-y-2">
                      <Label htmlFor="city" className="text-card-foreground">City</Label>
                      <Input
                        id="city"
                        name="city"
                        type="text"
                        value={formData.city}
                        onChange={handleInputChange}
                        required
                        className="text-foreground bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state" className="text-card-foreground">State</Label>
                      <Input
                        id="state"
                        name="state"
                        type="text"
                        value={formData.state}
                        onChange={handleInputChange}
                        required
                        className="text-foreground bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="zipCode" className="text-card-foreground">Zip Code</Label>
                      <Input
                        id="zipCode"
                        name="zipCode"
                        type="text"
                        value={formData.zipCode}
                        onChange={handleInputChange}
                        required
                        className="text-foreground bg-background"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="country" className="text-card-foreground">Country</Label>
                    <Input
                      id="country"
                      name="country"
                      type="text"
                      value={formData.country}
                      onChange={handleInputChange}
                      required
                      className="text-foreground bg-background"
                    />
                  </div>

                  <div className="pt-4 border-t border-border mt-6">
                    <h3 className="text-lg font-medium mb-4 text-card-foreground">Discount Code</h3>
                    <div className="flex gap-3">
                      <Input
                        id="discountCode"
                        name="discountCode"
                        type="text"
                        placeholder="Enter code"
                        value={formData.discountCode}
                        onChange={handleInputChange}
                        className="text-foreground bg-background flex-grow"
                      />
                      <Button type="button" variant="outline">Apply</Button>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-primary text-primary-foreground font-medium py-6 text-lg mt-8 rounded-xl transition-all active:scale-[0.98] disabled:opacity-50"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Processing Securely...
                      </>
                    ) : (
                      'Complete Purchase'
                    )}
                  </Button>
                </form>
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="bg-card rounded-2xl p-6 md:p-8 shadow-sm border border-border sticky top-24">
                <h2 className="text-2xl font-semibold mb-6 text-card-foreground">Order Summary</h2>
                <div className="space-y-6 mb-8 max-h-[40vh] overflow-y-auto pr-2">
                  {cartItems.map(item => {
                    const productPrice = item.variant.sale_price_in_cents || item.variant.price_in_cents;
                    
                    return (
                      <div key={item.variant.id} className="flex items-start space-x-4">
                        <div className="w-16 h-16 rounded-md bg-muted/30 overflow-hidden flex-shrink-0">
                          <img
                            src={item.product.image || item.product.imageUrl}
                            alt={item.product.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-grow min-w-0">
                          <p className="font-medium text-card-foreground truncate">{item.product.title}</p>
                          <p className="text-sm text-muted-foreground truncate mt-0.5">{item.variant.title}</p>
                          <p className="text-sm text-muted-foreground mt-0.5">Qty: {item.quantity}</p>
                        </div>
                        <p className="font-medium text-card-foreground flex-shrink-0">
                          {formatPriceUSD(productPrice)}
                        </p>
                      </div>
                    );
                  })}
                </div>

                <div className="border-t border-border pt-6 space-y-4">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Subtotal</span>
                    <span className="font-medium text-card-foreground">
                      {formatPriceUSD(subtotal)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Shipping</span>
                    <span className="font-medium text-card-foreground">
                      Free
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center pt-4 border-t border-border mt-4">
                    <span className="text-lg font-semibold text-card-foreground">Total</span>
                    <span className="text-2xl font-bold text-card-foreground tracking-tight">
                      {formatPriceUSD(total)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CheckoutPage;
