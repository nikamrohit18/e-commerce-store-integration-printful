
import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import ProductsList from '@/components/ProductsList.jsx';
import { getProducts as getStandardProducts } from '@/api/EcommerceApi.js';
import { usePrintfulSync } from '@/hooks/usePrintfulSync.jsx';
import { shouldShowProductOnPage } from '@/utils/productUtils.js';
import { Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

const KidsWearPage = () => {
  const [allProducts, setAllProducts] = useState([]);
  const [isStandardLoading, setIsStandardLoading] = useState(true);

  const { 
    products: printfulProducts, 
    isSyncing, 
    syncProducts, 
    getProducts: fetchPrintfulProducts 
  } = usePrintfulSync();

  useEffect(() => {
    const fetchStandardData = async () => {
      try {
        setIsStandardLoading(true);
        const productsResponse = await getStandardProducts();
        const fetchedProducts = productsResponse.products || [];
        setAllProducts(fetchedProducts);
        
        console.log(`[KidsWear] Fetched ${fetchedProducts.length} total products from backend`);
        console.log(`[KidsWear] First 5 products:`);
        fetchedProducts.slice(0, 5).forEach((p, i) => {
          console.log(`  ${i+1}. "${p.title || p.name}"`);
        });
      } catch (error) {
        console.error('Error fetching standard products:', error);
      } finally {
        setIsStandardLoading(false);
      }
    };

    fetchStandardData();
    fetchPrintfulProducts();
  }, [fetchPrintfulProducts]);

  const finalProducts = useMemo(() => {
    console.log(`[KidsWear] Filtering products...`);
    
    const combined = [...allProducts];
    const existingIds = new Set(combined.map(p => p.id));

    printfulProducts.forEach(p => {
      if (!existingIds.has(p.id)) {
        combined.push(p);
      }
    });

    const filtered = combined.filter(p => shouldShowProductOnPage(p.title || p.name, 'kids'));

    console.log(`[KidsWear] Filtered to ${filtered.length} products that should show on this page`);
    console.log(`[KidsWear] Products to display:`);
    filtered.forEach((p, i) => {
      console.log(`  ${i+1}. "${p.title || p.name}"`);
    });

    return filtered;
  }, [allProducts, printfulProducts]);

  const isLoading = isStandardLoading || isSyncing;

  return (
    <>
      <Helmet>
        <title>Kid-s Collection - LUXE Fashion</title>
        <meta name="description" content="Explore our premium Kid-s fashion collection." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <section
          className="relative h-[30vh] md:h-[40vh] flex items-center justify-center bg-cover bg-center"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1567958462451-4aa24566f6e5')` }}
        >
          <div className="absolute inset-0 bg-black/50" />
          <div className="relative z-10 text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 tracking-tight text-balance">Kid-s Collection</h1>
            <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto font-medium">Playful and comfortable fashion for little ones</p>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Products</h2>
              <p className="text-muted-foreground text-sm mt-1">Showing {finalProducts.length} products</p>
            </div>
            <Button 
              onClick={() => syncProducts()} 
              disabled={isSyncing}
              variant="outline" 
              className="bg-card hover:bg-accent shadow-sm whitespace-nowrap"
            >
              {isSyncing ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              {isSyncing ? 'Refreshing...' : 'Refresh for New Listing'}
            </Button>
          </div>

          <ProductsList 
            products={finalProducts} 
            isLoading={isLoading}
          />
        </div>
      </div>
    </>
  );
};

export default KidsWearPage;
