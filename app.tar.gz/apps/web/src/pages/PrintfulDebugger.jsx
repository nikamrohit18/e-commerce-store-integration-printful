
import React, { useState, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, CheckCircle2, XCircle, Activity, RefreshCw, TerminalSquare, List } from 'lucide-react';
import apiServerClient from '@/lib/apiServerClient.js';
import { usePrintfulSync } from '@/hooks/usePrintfulSync.jsx';

const PrintfulDebugger = () => {
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [testError, setTestError] = useState(null);
  const [syncResult, setSyncResult] = useState(null);
  
  const [logs, setLogs] = useState([]);
  const logsEndRef = useRef(null);
  
  const { syncProducts, isLoading, error: syncError } = usePrintfulSync();

  const addLog = (message, type = 'info', data = null) => {
    const timestamp = new Date().toISOString().split('T')[1].slice(0, -1);
    setLogs(prev => [...prev, { timestamp, message, type, data }]);
  };

  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  const handleGetProducts = async () => {
    setIsTesting(true);
    setTestResult(null);
    setTestError(null);
    addLog('Initiating GET /printful/products...', 'info');
    
    try {
      const response = await apiServerClient.fetch('/printful/products');
      
      if (!response.ok) {
        let errorMsg = `HTTP Error ${response.status}`;
        try {
          const errData = await response.json();
          errorMsg = errData.error || errData.message || errorMsg;
        } catch (e) {
          // Ignore
        }
        throw new Error(errorMsg);
      }
      
      const data = await response.json();
      
      setTestResult({
        productsCount: data.length,
        products: data
      });
      
      addLog(`GET successful. Found ${data.length} products.`, 'success', data);
    } catch (err) {
      setTestError(err.message);
      addLog(`GET failed: ${err.message}`, 'error');
    } finally {
      setIsTesting(false);
    }
  };

  const handleSyncProducts = async () => {
    setSyncResult(null);
    addLog('Initiating POST /printful/sync...', 'info');
    
    const data = await syncProducts();
    
    if (data && data.success) {
      setSyncResult(data);
      addLog(`Sync complete. Synchronized ${data.productsCount} products.`, 'success', data);
    } else {
      addLog(`Sync failed. Please check the error message above or the main error display.`, 'error');
    }
  };

  return (
    <>
      <Helmet>
        <title>Printful Debugger - Admin</title>
      </Helmet>
      
      <div className="min-h-screen bg-muted/30 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto space-y-8">
          
          <div>
            <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
              <TerminalSquare className="h-8 w-8 text-primary" />
              Printful Integration Debugger
            </h1>
            <p className="text-muted-foreground mt-2">
              Test API connectivity, manually trigger product synchronizations, and view raw response logs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Test GET Products Card */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <List className="h-5 w-5 text-blue-500" />
                  Test GET Products
                </CardTitle>
                <CardDescription>
                  Fetch products directly from GET /printful/products endpoint.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={handleGetProducts} 
                  disabled={isTesting || isLoading}
                  className="w-full"
                >
                  {isTesting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  {isTesting ? 'Fetching...' : 'GET /printful/products'}
                </Button>

                {testError && (
                  <Alert variant="destructive">
                    <XCircle className="h-4 w-4" />
                    <AlertTitle>Fetch Failed</AlertTitle>
                    <AlertDescription className="break-all">{testError}</AlertDescription>
                  </Alert>
                )}

                {testResult && (
                  <Alert className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                    <AlertTitle>Fetch Successful</AlertTitle>
                    <AlertDescription>
                      <div className="mt-2 space-y-2 text-sm">
                        <p><strong>Products Found:</strong> {testResult.productsCount}</p>
                        {testResult.productsCount > 0 && (
                          <div className="max-h-32 overflow-y-auto bg-emerald-500/5 p-2 rounded border border-emerald-500/10">
                            <ul className="list-disc pl-4 space-y-1">
                              {testResult.products.map((p, i) => (
                                <li key={i} className="truncate">{p.name || p.title || 'Unnamed Product'}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Sync Products Card */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RefreshCw className="h-5 w-5 text-purple-500" />
                  Test POST Sync
                </CardTitle>
                <CardDescription>
                  Trigger a fresh sync via POST /printful/sync endpoint.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={handleSyncProducts} 
                  disabled={isTesting || isLoading}
                  variant="secondary"
                  className="w-full"
                >
                  {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  {isLoading ? 'Syncing...' : 'POST /printful/sync'}
                </Button>

                {syncError && (
                  <Alert variant="destructive">
                    <XCircle className="h-4 w-4" />
                    <AlertTitle>Sync Failed</AlertTitle>
                    <AlertDescription className="break-all">{syncError}</AlertDescription>
                  </Alert>
                )}

                {syncResult && (
                  <Alert className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                    <AlertTitle>Sync Complete</AlertTitle>
                    <AlertDescription>
                      <div className="mt-2 space-y-2 text-sm">
                        <p><strong>Products Synced:</strong> {syncResult.productsCount}</p>
                        <p><strong>Duration:</strong> {syncResult.syncDurationMs}ms</p>
                        {syncResult.products && syncResult.products.length > 0 && (
                          <div className="max-h-32 overflow-y-auto bg-emerald-500/5 p-2 rounded border border-emerald-500/10">
                            <ul className="list-disc pl-4 space-y-1">
                              {syncResult.products.map((p, i) => (
                                <li key={i} className="truncate">{p.name || p.title || 'Unnamed Product'}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Logs Section */}
          <Card className="shadow-sm border-slate-800 bg-slate-950 text-slate-300">
            <CardHeader className="border-b border-slate-800 pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-slate-100 text-lg">System Logs & Raw Data</CardTitle>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setLogs([])}
                  className="h-8 text-slate-400 hover:text-slate-100 hover:bg-slate-800"
                >
                  Clear Logs
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[400px] overflow-y-auto p-4 font-mono text-sm space-y-3">
                {logs.length === 0 ? (
                  <div className="text-slate-600 italic">No logs to display. Run a test or sync to generate logs.</div>
                ) : (
                  logs.map((log, i) => (
                    <div key={i} className="space-y-1">
                      <div className="flex items-start gap-2">
                        <span className="text-slate-500 shrink-0">[{log.timestamp}]</span>
                        <span className={`
                          ${log.type === 'error' ? 'text-red-400' : ''}
                          ${log.type === 'success' ? 'text-emerald-400' : ''}
                          ${log.type === 'info' ? 'text-blue-400' : ''}
                        `}>
                          {log.message}
                        </span>
                      </div>
                      {log.data && (
                        <div className="pl-24 pr-4">
                          <pre className="bg-slate-900 p-3 rounded-md overflow-x-auto text-xs text-slate-400 border border-slate-800">
                            {JSON.stringify(log.data, null, 2)}
                          </pre>
                        </div>
                      )}
                    </div>
                  ))
                )}
                <div ref={logsEndRef} />
              </div>
            </CardContent>
          </Card>

        </div>
      </div>
    </>
  );
};

export default PrintfulDebugger;
