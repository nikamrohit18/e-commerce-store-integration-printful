
import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import ProductsList from '@/components/ProductsList.jsx';
import { getProducts as getStandardProducts } from '@/api/EcommerceApi.js';
import { usePrintfulSync } from '@/hooks/usePrintfulSync.jsx';
import { shouldShowProductOnBabyPage } from '@/utils/productUtils.js';
import { Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

const BabyWearPage = () => {
  const [allProducts, setAllProducts] = useState([]);
  const [isStandardLoading, setIsStandardLoading] = useState(true);

  const { 
    products: printfulProducts, 
    isSyncing, 
    syncProducts, 
    getProducts: fetchPrintfulProducts,
    syncError
  } = usePrintfulSync();

  useEffect(() => {
    const fetchStandardData = async () => {
      try {
        setIsStandardLoading(true);
        const productsResponse = await getStandardProducts();
        const fetchedProducts = productsResponse.products || [];
        setAllProducts(fetchedProducts);
      } catch (error) {
        console.error('Error fetching standard products:', error);
      } finally {
        setIsStandardLoading(false);
      }
    };

    fetchStandardData();
    fetchPrintfulProducts();
  }, [fetchPrintfulProducts]);

  useEffect(() => {
    if (syncError) {
      console.error(`[BabyWear] Sync Error:`, syncError);
    }
  }, [syncError]);

  const finalProducts = useMemo(() => {
    console.log("[BabyWear] Starting filter process...");
    const combined = [...allProducts];
    const existingIds = new Set(combined.map(p => p.id));

    printfulProducts.forEach(p => {
      if (!existingIds.has(p.id)) {
        combined.push(p);
      }
    });

    console.log(`[BabyWear] Total products before filter: ${combined.length}`);

    const filtered = combined
      .filter(p => {
        const title = p.title || p.name || "";
        const isBaby = shouldShowProductOnBabyPage(title);
        console.log(`[BabyWear] Filter check - Title: "${title}" | Passes: ${isBaby}`);
        return isBaby;
      })
      .map(p => {
        // Use a working royalty-free baby product image if the product doesn't have one
        const imgUrl = p.imageUrl || p.image || p.thumbnail_url || p.preview_url || p.sync_product?.thumbnail_url;
        return {
          ...p,
          imageUrl: imgUrl || 'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4'
        };
      });

    console.log(`[BabyWear] Final products to display: ${filtered.length}`);
    if (filtered.length === 0) {
      console.log("[BabyWear] No products to display (all filtered out)");
    }

    return filtered;
  }, [allProducts, printfulProducts]);

  const isLoading = isStandardLoading || isSyncing;

  return (
    <>
      <Helmet>
        <title>Baby & Infants - LUXE Fashion</title>
        <meta name="description" content="Explore our premium Baby & Infants fashion collection." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <section
          className="relative h-[30vh] md:h-[40vh] flex items-center justify-center bg-cover bg-center"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1519689680058-324335c77eba')` }}
        >
          <div className="absolute inset-0 bg-black/50" />
          <div className="relative z-10 text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 tracking-tight text-balance">Baby & Infants</h1>
            <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto font-medium">Soft, comfortable, and adorable essentials</p>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Products</h2>
              <p className="text-muted-foreground text-sm mt-1">Showing {finalProducts.length} products</p>
            </div>
            <Button 
              onClick={() => syncProducts()} 
              disabled={isSyncing}
              variant="outline" 
              className="bg-card hover:bg-accent shadow-sm whitespace-nowrap"
            >
              {isSyncing ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              {isSyncing ? 'Refreshing...' : 'Refresh for New Listing'}
            </Button>
          </div>

          <ProductsList 
            products={finalProducts} 
            isLoading={isLoading}
          />
        </div>
      </div>
    </>
  );
};

export default BabyWearPage;
