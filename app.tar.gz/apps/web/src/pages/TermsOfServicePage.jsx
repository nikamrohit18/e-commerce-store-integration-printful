
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

const TermsOfServicePage = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service - LUXE Fashion</title>
        <meta
          name="description"
          content="Terms of Service for LUXE Fashion. Read our terms and conditions regarding purchases, shipping, returns, and website usage."
        />
      </Helmet>

      <div className="min-h-screen bg-background py-20 px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto"
        >
          <div className="mb-12 text-center text-balance">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              Terms of service
            </h1>
            <p className="text-muted-foreground text-lg">
              Effective Date: May 18, 2026
            </p>
          </div>

          <div className="prose prose-slate dark:prose-invert max-w-none space-y-10">
            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Product descriptions and accuracy</h2>
              <p className="text-muted-foreground leading-relaxed">
                LUXE Fashion attempts to be as accurate as possible when describing our products. However, we do not warrant that product descriptions or other content of this site is completely accurate, complete, reliable, current, or error-free. If a product offered by us is not as described, your sole remedy is to return it in unused condition. We have made every effort to display as accurately as possible the colors and images of our products that appear at the store.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Pricing and availability</h2>
              <p className="text-muted-foreground leading-relaxed">
                All prices are subject to change without notice. We reserve the right at any time to modify or discontinue the Service (or any part or content thereof) without notice at any time. We shall not be liable to you or to any third-party for any modification, price change, suspension, or discontinuance of the Service. Certain products or services may be available exclusively online through the website and may have limited quantities.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Payment terms</h2>
              <p className="text-muted-foreground leading-relaxed">
                By submitting an order, you represent and warrant that you are authorized to use the designated payment method and authorize us to charge your order (including taxes, shipping and handling) to that payment method. If the payment method cannot be verified, is invalid or is otherwise not acceptable, your order may be suspended or cancelled automatically.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Shipping and delivery</h2>
              <p className="text-muted-foreground leading-relaxed">
                We aim to deliver products to you at the place of delivery requested by you in your order. We will try to let you know if we expect that we are unable to meet our estimated delivery date, but, to the extent permitted by law, we shall not be liable to you for any losses, liabilities, costs, damages, charges or expenses arising out of late delivery.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Returns and refunds policy</h2>
              <p className="text-muted-foreground leading-relaxed">
                Our policy lasts 30 days. If 30 days have gone by since your purchase, unfortunately, we cannot offer you a refund or exchange. To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging. Once your return is received and inspected, we will notify you of the approval or rejection of your refund.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Limitation of liability</h2>
              <p className="text-muted-foreground leading-relaxed">
                In no case shall LUXE Fashion, our directors, officers, employees, affiliates, agents, contractors, interns, suppliers, service providers or licensors be liable for any injury, loss, claim, or any direct, indirect, incidental, punitive, special, or consequential damages of any kind, including, without limitation lost profits, lost revenue, lost savings, loss of data, replacement costs, or any similar damages.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">User conduct and prohibited activities</h2>
              <p className="text-muted-foreground leading-relaxed">
                You are prohibited from using the site or its content: (a) for any unlawful purpose; (b) to solicit others to perform or participate in any unlawful acts; (c) to violate any international, federal, provincial or state regulations, rules, laws, or local ordinances; (d) to infringe upon or violate our intellectual property rights or the intellectual property rights of others; (e) to submit false or misleading information.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Contact information</h2>
              <p className="text-muted-foreground leading-relaxed">
                Questions about the Terms of Service should be sent to us at:
              </p>
              <div className="mt-4 p-6 bg-muted rounded-xl">
                <p className="font-medium text-foreground mb-1">LUXE Fashion Legal Team</p>
                <p className="text-muted-foreground">Email: legal@luxefashion.style</p>
                <p className="text-muted-foreground">Address: 123 Fashion Avenue, Suite 100, New York, NY 10001</p>
              </div>
            </section>
          </div>

          <div className="mt-16 pt-8 border-t border-border flex justify-center">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to home
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default TermsOfServicePage;
