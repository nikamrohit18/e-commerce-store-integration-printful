
import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import ProductsList from '@/components/ProductsList.jsx';
import { getProducts as getStandardProducts } from '@/api/EcommerceApi.js';
import { usePrintfulSync } from '@/hooks/usePrintfulSync.jsx';
import { Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Helper to robustly extract price since EcommerceApi is read-only and Printful data might vary
const extractPriceInCents = (product) => {
  if (product.price_in_cents && product.price_in_cents > 0) return product.price_in_cents;
  
  // Check Printful specific fields
  if (product.retail_price) return Math.round(parseFloat(product.retail_price) * 100);
  if (product.price) return Math.round(parseFloat(product.price) * 100);
  if (product.sync_product?.retail_price) return Math.round(parseFloat(product.sync_product.retail_price) * 100);
  
  // Check variants
  if (product.variants?.[0]) {
    const v = product.variants[0];
    if (v.price_in_cents > 0) return v.price_in_cents;
    if (v.retail_price) return Math.round(parseFloat(v.retail_price) * 100);
    if (v.price) return Math.round(parseFloat(v.price) * 100);
  }

  return 2999; // Default fallback price
};

const ShopAllPage = () => {
  const [allProducts, setAllProducts] = useState([]);
  const [isStandardLoading, setIsStandardLoading] = useState(true);

  const { 
    products: printfulProducts, 
    isSyncing, 
    syncProducts, 
    getProducts: fetchPrintfulProducts 
  } = usePrintfulSync();

  // Fetch all products
  useEffect(() => {
    const fetchStandardData = async () => {
      try {
        setIsStandardLoading(true);
        const productsResponse = await getStandardProducts();
        setAllProducts(prev => {
          // Merge standard products, avoiding duplicates if any
          const existingIds = new Set(prev.map(p => p.id));
          const newStandard = productsResponse.products.filter(p => !existingIds.has(p.id));
          return [...prev, ...newStandard];
        });
      } catch (error) {
        console.error('Error fetching standard products:', error);
      } finally {
        setIsStandardLoading(false);
      }
    };

    fetchStandardData();
    fetchPrintfulProducts();
  }, [fetchPrintfulProducts]);

  // Process and merge products with robust price extraction
  const processedProducts = useMemo(() => {
    const combined = [...allProducts];
    
    // Add printful products that aren't already in the list
    const existingIds = new Set(combined.map(p => p.id));
    printfulProducts.forEach(p => {
      if (!existingIds.has(p.id)) {
        combined.push(p);
      }
    });

    return combined.map(p => {
      const price = extractPriceInCents(p);
      return {
        ...p,
        calculated_price_in_cents: price
      };
    });
  }, [allProducts, printfulProducts]);

  const isLoading = isStandardLoading || isSyncing;

  return (
    <>
      <Helmet>
        <title>Shop All Products - LUXE Fashion</title>
        <meta name="description" content="Browse our complete collection of premium apparel and accessories." />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Hero Section */}
        <section
          className="relative h-[30vh] md:h-[40vh] flex items-center justify-center bg-cover bg-center"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1441984904996-e0b6ba687e04')` }}
        >
          <div className="absolute inset-0 bg-black/60" />
          <div className="relative z-10 text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 tracking-tight text-balance">Shop All Products</h1>
            <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto font-medium">Discover our complete collection of premium styles</p>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4 border-b pb-6">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Our Catalog</h2>
              <p className="text-muted-foreground text-sm mt-1">Showing {processedProducts.length} items</p>
            </div>
            <Button 
              onClick={() => syncProducts()} 
              disabled={isSyncing}
              variant="outline" 
              className="bg-card hover:bg-accent shadow-sm whitespace-nowrap"
            >
              {isSyncing ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              {isSyncing ? 'Refreshing...' : 'Refresh Products'}
            </Button>
          </div>
          
          <ProductsList 
            products={processedProducts} 
            isLoading={isLoading}
          />
        </div>
      </div>
    </>
  );
};

export default ShopAllPage;
