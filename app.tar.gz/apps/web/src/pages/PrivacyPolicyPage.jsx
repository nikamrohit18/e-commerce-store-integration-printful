
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

const PrivacyPolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy - LUXE Fashion</title>
        <meta
          name="description"
          content="Privacy Policy for LUXE Fashion. Learn about how we collect, use, and protect your personal data."
        />
      </Helmet>

      <div className="min-h-screen bg-background py-20 px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto"
        >
          <div className="mb-12 text-center text-balance">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              Privacy policy
            </h1>
            <p className="text-muted-foreground text-lg">
              Effective Date: May 18, 2026
            </p>
          </div>

          <div className="prose prose-slate dark:prose-invert max-w-none space-y-10">
            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Data collection</h2>
              <p className="text-muted-foreground leading-relaxed">
                At LUXE Fashion, we are committed to protecting your privacy and ensuring your personal information is handled in a safe and responsible manner. We collect personal data when you create an account, place an order, sign up for our newsletter, or interact with our website. The types of personal information we may collect include your name, email address, shipping and billing address, phone number, and payment information.
              </p>
              <p className="text-muted-foreground leading-relaxed mt-4">
                We also automatically collect non-personally identifiable information such as your IP address, browser type, operating system, and browsing behavior on our website to improve your shopping experience.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Data usage</h2>
              <p className="text-muted-foreground leading-relaxed">
                The data we collect is primarily used to process your orders, process payments, arrange for shipping, and provide you with invoices and/or order confirmations. Additionally, we use this information to communicate with you, screen our orders for potential risk or fraud, and, when in line with the preferences you have shared with us, provide you with information or advertising relating to our products or services.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Cookies</h2>
              <p className="text-muted-foreground leading-relaxed">
                We use cookies and similar tracking technologies to track the activity on our service and hold certain information. Cookies are files with small amount of data which may include an anonymous unique identifier. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our service, such as retaining items in your shopping cart between visits.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">User rights</h2>
              <p className="text-muted-foreground leading-relaxed">
                Depending on your location, you may have certain rights under applicable data protection laws (such as GDPR or CCPA). These rights may include the right to access, update, or delete the information we have on you. You also have the right to rectification, the right to object, the right of restriction, the right to data portability, and the right to withdraw consent. If you would like to exercise any of these rights, please contact us using the information provided below.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-foreground">Contact information</h2>
              <p className="text-muted-foreground leading-relaxed">
                If you have any questions about this Privacy Policy, the practices of this site, or your dealings with this site, please contact us at:
              </p>
              <div className="mt-4 p-6 bg-muted rounded-xl">
                <p className="font-medium text-foreground mb-1">LUXE Fashion Privacy Team</p>
                <p className="text-muted-foreground">Email: privacy@luxefashion.style</p>
                <p className="text-muted-foreground">Phone: +1 (555) 123-4567</p>
              </div>
            </section>
          </div>

          <div className="mt-16 pt-8 border-t border-border flex justify-center">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to home
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default PrivacyPolicyPage;
