
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles, Shield, Truck, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { getProducts, formatCurrency } from '@/api/EcommerceApi.js';
import { shouldShowProductOnBabyPage } from '@/utils/productUtils.js';

const HomePage = () => {
  const [babyProducts, setBabyProducts] = useState([]);
  const [isLoadingBaby, setIsLoadingBaby] = useState(true);

  useEffect(() => {
    const fetchBabyProducts = async () => {
      try {
        setIsLoadingBaby(true);
        const response = await getProducts();
        const filtered = (response.products || [])
          .filter(p => shouldShowProductOnBabyPage(p.title || p.name))
          .slice(0, 4);
        setBabyProducts(filtered);
      } catch (error) {
        console.error("Failed to fetch products", error);
      } finally {
        setIsLoadingBaby(false);
      }
    };

    fetchBabyProducts();
  }, []);

  const collections = [
    {
      title: "Essential Basics",
      description: 'Comfortable everyday wear for your wardrobe',
      image: 'https://images.unsplash.com/photo-1593030836865-ae3fbd0a5d58',
      link: '/shop',
    },
    {
      title: "New Arrivals",
      description: 'Discover the latest additions to our catalog',
      image: 'https://images.unsplash.com/photo-1694201211076-8f9ef6f6386e',
      link: '/shop',
    },
    {
      title: "Accessories",
      description: 'Complete your look with premium accessories',
      image: 'https://images.unsplash.com/photo-1567958462451-4aa24566f6e5',
      link: '/shop',
    },
  ];

  const values = [
    {
      icon: Sparkles,
      title: 'Premium Quality',
      description: 'Carefully curated materials and expert craftsmanship in every piece',
    },
    {
      icon: Shield,
      title: 'Sustainable Fashion',
      description: 'Committed to ethical production and environmental responsibility',
    },
    {
      icon: Truck,
      title: 'Fast Delivery',
      description: 'Free shipping on orders over $100 with express options available',
    },
  ];

  return (
    <>
      <Helmet>
        <title>LUXE Fashion - Premium Clothing for Every Style</title>
        <meta
          name="description"
          content="Discover our complete premium fashion collection. Quality craftsmanship meets timeless design at LUXE Fashion."
        />
      </Helmet>

      <div className="min-h-screen">
        <section
          className="relative h-[90vh] flex items-center justify-center bg-cover bg-center"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1678547241895-1c307914b50c')` }}
        >
          <div className="absolute inset-0 hero-overlay" />
          <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6"
            >
              Discover your next favorite look
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl md:text-2xl mb-8 text-white/90"
            >
              Explore our unified collection of timeless, premium apparel
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Link to="/shop">
                <Button
                  size="lg"
                  className="bg-white text-foreground hover:bg-white/90 font-semibold px-8 py-6 text-lg"
                >
                  Shop Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
                Featured Highlights
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Explore our carefully curated selections designed for every occasion
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {collections.map((collection, index) => (
                <motion.div
                  key={collection.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Link to={collection.link}>
                    <div className="group relative overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                      <div className="aspect-[4/5] overflow-hidden">
                        <img
                          src={collection.image}
                          alt={collection.title}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                      </div>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                        <h3 className="text-2xl font-bold mb-2">{collection.title}</h3>
                        <p className="text-white/90 text-sm">{collection.description}</p>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted/30 border-t">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
                  Trending Styles
                </h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Check out our most popular pieces loved by customers worldwide.
                </p>
                <Link to="/shop">
                  <Button variant="outline" className="group">
                    View Entire Catalog
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
              </div>
              <div className="relative aspect-[16/9] lg:aspect-[4/3] overflow-hidden rounded-2xl shadow-lg">
                <img
                  src="https://images.unsplash.com/photo-1608469926524-c4ea13b411aa"
                  alt="trending fashion styles"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {isLoadingBaby ? (
              <div className="flex justify-center items-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : babyProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {babyProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Link to={`/product/${product.id}`} className="group block h-full">
                      <div className="rounded-2xl border bg-card text-card-foreground shadow-sm overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1 h-full flex flex-col">
                        <div className="relative aspect-square overflow-hidden bg-muted/20">
                          <img
                            src={product.image || product.imageUrl || 'https://via.placeholder.com/300x300?text=Product'}
                            alt={product.title || product.name}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                            loading="lazy"
                          />
                        </div>
                        <div className="p-5 flex flex-col flex-grow">
                          <h3 className="text-lg font-bold truncate mb-1">{product.title || product.name}</h3>
                          <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-grow">
                            {product.subtitle || product.description || 'Premium quality design and comfort.'}
                          </p>
                          <div className="font-semibold text-foreground">
                            {formatCurrency(product.price_in_cents || 2999, { code: product.currency || 'USD', symbol: '$' })}
                          </div>
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-card rounded-2xl border border-dashed">
                <p className="text-muted-foreground">No featured products available at the moment.</p>
              </div>
            )}
          </div>
        </section>

        <section className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
                  Our Story
                </h2>
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Founded with a passion for timeless design and exceptional quality, LUXE Fashion brings you carefully crafted pieces that transcend trends. Each garment is a testament to our commitment to sustainable practices and ethical production.
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  We believe fashion should be both beautiful and responsible. That's why we partner with artisans who share our values, creating collections that you'll treasure for years to come.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="grid grid-cols-1 gap-8"
              >
                {values.map((value, index) => (
                  <div key={value.title} className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <value.icon className="h-6 w-6 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2 text-foreground">{value.title}</h3>
                      <p className="text-muted-foreground">{value.description}</p>
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Ready to discover your style?
              </h2>
              <p className="text-xl text-secondary-foreground/80 mb-8">
                Browse our complete collection and find pieces that speak to you
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/shop">
                  <Button
                    size="lg"
                    className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
                  >
                    Browse All Products
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;
