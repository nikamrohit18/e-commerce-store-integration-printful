import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const SuccessPage = () => {
  const orderNumber = `ORD-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  const estimatedDelivery = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <>
      <Helmet>
        <title>Order Confirmed - LUXE Fashion</title>
        <meta name="description" content="Your order has been successfully placed at LUXE Fashion." />
      </Helmet>

      <div className="min-h-screen flex items-center justify-center bg-muted py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
        >
          <div className="bg-card rounded-lg p-8 shadow-lg">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="flex justify-center mb-6"
            >
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-12 w-12 text-green-600" />
              </div>
            </motion.div>

            <h1 className="text-4xl font-bold mb-4 text-card-foreground">Order Confirmed</h1>
            <p className="text-lg text-muted-foreground mb-8">
              Thank you for your purchase! Your order has been successfully placed.
            </p>

            <div className="bg-muted rounded-lg p-6 mb-8 text-left">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Order Number:</span>
                  <span className="font-semibold text-card-foreground">{orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Estimated Delivery:</span>
                  <span className="font-semibold text-card-foreground">{estimatedDelivery}</span>
                </div>
              </div>
            </div>

            <p className="text-muted-foreground mb-8">
              A confirmation email has been sent to your email address with order details and tracking information.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/">
                <Button className="bg-secondary text-secondary-foreground hover:bg-secondary/90 font-semibold px-8">
                  Continue Shopping
                </Button>
              </Link>
              <Link to="/orders">
                <Button variant="outline" className="font-semibold px-8">
                  View Orders
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default SuccessPage;