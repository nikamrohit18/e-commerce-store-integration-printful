
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from '@/hooks/useCart.jsx';
import { Toaster } from '@/components/ui/sonner';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ShoppingCart from '@/components/ShoppingCart.jsx';
import ScrollToTop from '@/components/ScrollToTop.jsx';

// Pages
import HomePage from '@/pages/HomePage.jsx';
import ShopAllPage from '@/pages/ShopAllPage.jsx';
import ProductDetailPage from '@/pages/ProductDetailPage.jsx';
import CheckoutPage from '@/pages/CheckoutPage.jsx';
import SuccessPage from '@/pages/SuccessPage.jsx';
import PrivacyPolicyPage from '@/pages/PrivacyPolicyPage.jsx';
import TermsOfServicePage from '@/pages/TermsOfServicePage.jsx';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);

  return (
    <CartProvider>
      <Router>
        <ScrollToTop />
        <div className="flex flex-col min-h-screen bg-background text-foreground">
          <Header onCartClick={() => setIsCartOpen(true)} />
          
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/shop" element={<ShopAllPage />} />
              <Route path="/product/:id" element={<ProductDetailPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/success" element={<SuccessPage />} />
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/terms-of-service" element={<TermsOfServicePage />} />
              
              {/* Catch-all 404 */}
              <Route path="*" element={
                <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
                  <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
                  <h2 className="text-2xl font-semibold mb-6">Page Not Found</h2>
                  <p className="text-muted-foreground mb-8 max-w-md">
                    The page you are looking for doesn't exist or has been moved.
                  </p>
                  <a href="/" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                    Back to Home
                  </a>
                </div>
              } />
            </Routes>
          </main>

          <Footer />
          
          <ShoppingCart 
            isCartOpen={isCartOpen} 
            setIsCartOpen={setIsCartOpen} 
          />
        </div>
        <Toaster position="bottom-right" />
      </Router>
    </CartProvider>
  );
}

export default App;
