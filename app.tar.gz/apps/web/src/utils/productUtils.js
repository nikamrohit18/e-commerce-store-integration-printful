
export const shouldShowProductOnPage = (productName, pageType) => {
  const name = productName || "";
  
  const hasMens = name.includes("Men-s") || name.includes("Mens");
  const hasWomens = name.includes("Women-s") || name.includes("Womens");
  const hasKids = name.includes("Kid-s") || name.includes("Kids");
  const hasBaby = name.includes("Baby-s") || name.includes("Baby");
  const hasInfant = name.includes("Infant-s") || name.includes("Infant");
  const hasUnisex = name.includes("Unisex");
  
  let shouldShow = false;
  
  if (pageType === 'mens') {
    shouldShow = hasMens || hasUnisex;
  } else if (pageType === 'womens') {
    shouldShow = hasWomens || hasUnisex;
  } else if (pageType === 'kids') {
    shouldShow = hasKids || hasUnisex;
  } else if (pageType === 'baby') {
    shouldShow = hasBaby || hasInfant || hasUnisex;
  } else if (pageType === 'all') {
    shouldShow = true;
  }
  
  return shouldShow;
};

export const shouldShowProductOnBabyPage = (productName) => {
  // Convert to lowercase for case-insensitive matching
  const name = (productName || "").toLowerCase();
  
  const hasBaby = name.includes("baby");
  const hasInfant = name.includes("infant");
  
  const hasUnisex = name.includes("unisex");
  const hasMens = name.includes("men-s") || name.includes("mens");
  const hasWomens = name.includes("women-s") || name.includes("womens");
  const hasKids = name.includes("kid-s") || name.includes("kids");
  
  if (hasUnisex || hasMens || hasWomens || hasKids) {
    return false;
  }
  
  return hasBaby || hasInfant;
};

export const extractProductTypeFromName = (name) => {
  if (!name) return 'Apparel';
  
  const lower = name.toLowerCase();
  if (lower.includes('t-shirt') || lower.includes('tshirt') || lower.includes('tee')) return 'T-Shirts';
  if (lower.includes('hoodie')) return 'Hoodies';
  if (lower.includes('sweatshirt')) return 'Sweatshirts';
  if (lower.includes('bag') || lower.includes('tote')) return 'Bags';
  if (lower.includes('hat') || lower.includes('cap') || lower.includes('beanie')) return 'Headwear';
  if (lower.includes('mug')) return 'Mugs';
  if (lower.includes('jacket')) return 'Jackets';
  if (lower.includes('pants')) return 'Pants';
  if (lower.includes('shorts')) return 'Shorts';
  if (lower.includes('socks')) return 'Socks';
  if (lower.includes('dress')) return 'Dresses';
  if (lower.includes('romper') || lower.includes('bodysuit') || lower.includes('onesie')) return 'Babywear';
  
  const words = name.split(' ');
  const lastWord = words[words.length - 1];
  
  if (!lastWord) return 'Apparel';
  
  return lastWord.charAt(0).toUpperCase() + lastWord.slice(1);
};
