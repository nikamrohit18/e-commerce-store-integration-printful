
export const formatPriceUSD = (price) => {
  if (price === null || price === undefined) return '';
  
  // Handle string prices with ฿ symbol or other currencies - strip it
  if (typeof price === 'string') {
    const cleanPrice = price.replace(/[฿$,]/g, '').trim();
    return '$' + parseFloat(cleanPrice).toFixed(2);
  }
  
  // Handle numbers (assuming cents from EcommerceApi)
  return '$' + (Number(price) / 100).toFixed(2);
};
