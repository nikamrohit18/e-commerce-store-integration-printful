
import React, { useState, useMemo, useEffect } from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { ChevronDown, ChevronUp, FilterX } from 'lucide-react';
import { extractProductTypeFromName } from '@/utils/productUtils.js';

const ProductTypeFilter = ({ products, onApplyFilters, initialFilters }) => {
  const [expandedSections, setExpandedSections] = useState({
    type: true,
    price: true,
  });

  const [selectedTypes, setSelectedTypes] = useState(initialFilters?.types || []);
  const [priceRange, setPriceRange] = useState(initialFilters?.priceRange || [0, 200]);
  const [minInput, setMinInput] = useState(initialFilters?.priceRange?.[0] || 0);
  const [maxInput, setMaxInput] = useState(initialFilters?.priceRange?.[1] || 200);

  // Extract unique product types dynamically from the current filtered products array
  const typeStats = useMemo(() => {
    const stats = {};
    products.forEach(p => {
      // Prioritize the type already extracted by the parent, fallback to extracting it here
      const type = p.extracted_type || extractProductTypeFromName(p.title || p.name);
      stats[type] = (stats[type] || 0) + 1;
    });
    
    return Object.entries(stats)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count); // Sort by count descending
  }, [products]);

  // Sync inputs when slider changes
  useEffect(() => {
    setMinInput(priceRange[0]);
    setMaxInput(priceRange[1]);
  }, [priceRange]);

  // Pass active selections back whenever they apply
  const handleApplyFilters = () => {
    onApplyFilters({
      types: selectedTypes,
      priceRange: priceRange,
    });
  };

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const handleTypeChange = (type) => {
    const newTypes = selectedTypes.includes(type)
      ? selectedTypes.filter(t => t !== type)
      : [...selectedTypes, type];
    setSelectedTypes(newTypes);
  };

  const handleMinInputChange = (e) => {
    const val = parseInt(e.target.value) || 0;
    setMinInput(val);
    if (val <= priceRange[1]) {
      setPriceRange([val, priceRange[1]]);
    }
  };

  const handleMaxInputChange = (e) => {
    const val = parseInt(e.target.value) || 0;
    setMaxInput(val);
    if (val >= priceRange[0]) {
      setPriceRange([priceRange[0], val]);
    }
  };

  const handleClearFilters = () => {
    setSelectedTypes([]);
    setPriceRange([0, 200]);
    setMinInput(0);
    setMaxInput(200);
    onApplyFilters({
      types: [],
      priceRange: [0, 200],
    });
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-6 space-y-6 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-card-foreground">Filters</h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleClearFilters}
          className="text-muted-foreground hover:text-foreground h-8 px-2"
        >
          <FilterX className="h-4 w-4 mr-1.5" />
          Clear
        </Button>
      </div>

      <div className="space-y-6">
        {/* Product Type Section */}
        <div className="border-b border-border pb-6">
          <button
            onClick={() => toggleSection('type')}
            className="flex items-center justify-between w-full text-left group"
          >
            <span className="font-semibold text-card-foreground group-hover:text-primary transition-colors">Product Type</span>
            {expandedSections.type ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
          
          {expandedSections.type && (
            <div className="mt-4 space-y-3 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
              {typeStats.length === 0 ? (
                <p className="text-sm text-muted-foreground">No types available</p>
              ) : (
                typeStats.map(({ name, count }) => (
                  <div key={name} className="flex items-center space-x-3">
                    <Checkbox
                      id={`type-${name}`}
                      checked={selectedTypes.includes(name)}
                      onCheckedChange={() => handleTypeChange(name)}
                      className="rounded-[4px]"
                    />
                    <Label
                      htmlFor={`type-${name}`}
                      className="text-sm text-card-foreground cursor-pointer flex-1 flex justify-between items-center font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      <span>{name}</span>
                      <span className="text-muted-foreground text-xs bg-muted px-2 py-0.5 rounded-full">{count}</span>
                    </Label>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Price Range Section */}
        <div className="pb-2">
          <button
            onClick={() => toggleSection('price')}
            className="flex items-center justify-between w-full text-left group"
          >
            <span className="font-semibold text-card-foreground group-hover:text-primary transition-colors">Price Range</span>
            {expandedSections.price ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
          
          {expandedSections.price && (
            <div className="mt-6 space-y-6">
              <div className="text-center font-medium text-sm text-primary bg-primary/10 py-1.5 rounded-md">
                ${priceRange[0]} - ${priceRange[1]}
              </div>
              
              <Slider
                value={priceRange}
                onValueChange={setPriceRange}
                max={200}
                step={1}
                className="w-full"
              />
              
              <div className="flex items-center justify-between gap-4">
                <div className="space-y-1.5 flex-1">
                  <Label htmlFor="min-price" className="text-xs text-muted-foreground">Min Price</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                    <Input 
                      id="min-price"
                      type="number" 
                      value={minInput} 
                      onChange={handleMinInputChange}
                      className="pl-7 h-9 text-sm"
                    />
                  </div>
                </div>
                <div className="space-y-1.5 flex-1">
                  <Label htmlFor="max-price" className="text-xs text-muted-foreground">Max Price</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                    <Input 
                      id="max-price"
                      type="number" 
                      value={maxInput} 
                      onChange={handleMaxInputChange}
                      className="pl-7 h-9 text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <Button
        onClick={handleApplyFilters}
        className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-sm"
      >
        Apply Filters
      </Button>
    </div>
  );
};

export default ProductTypeFilter;
