
import React, { useCallback, useMemo, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Loader2, AlertCircle, Image as ImageIcon } from 'lucide-react';
import { useCart } from '@/hooks/useCart.jsx';
import { useToast } from '@/hooks/use-toast.js';
import { getProducts, getProductQuantities } from '@/api/EcommerceApi.js';
import { formatPriceUSD } from '@/utils/priceFormatter.js';

const ProductCard = ({ product, index }) => {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [imageLoaded, setImageLoaded] = useState(false);

  const displayVariant = useMemo(() => product?.variants?.[0] || {}, [product]);
  
  const priceInCents = product.calculated_price_in_cents || product.price_in_cents || 2999;
  const salePriceInCents = displayVariant.sale_price_in_cents;
  const hasSale = salePriceInCents !== null && salePriceInCents !== undefined && salePriceInCents < priceInCents;
  
  const displayPrice = hasSale ? formatPriceUSD(salePriceInCents) : formatPriceUSD(priceInCents);
  const originalPrice = hasSale ? formatPriceUSD(priceInCents) : null;
  
  const displayCategory = product?.extracted_type || product?.category || product?.type?.value || 'Apparel';
  
  const imgSrc = product.image || product.imageUrl;
  
  const handleAddToCart = useCallback(async (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (product.variants?.length > 1 && !product.isPrintful) {
      navigate(`/product/${product.id}`);
      return;
    }

    const defaultVariant = product.variants?.[0];

    try {
      const cartProduct = { ...product, price_in_cents: priceInCents };
      await addToCart(cartProduct, defaultVariant, 1, defaultVariant?.inventory_quantity || 999);
      toast({
        title: "Added to Cart! 🛒",
        description: `${product.title || product.name} has been added to your cart.`,
      });
    } catch (error) {
      toast({
        title: "Error adding to cart",
        description: error.message,
        variant: "destructive"
      });
    }
  }, [product, priceInCents, addToCart, toast, navigate]);

  if (!product) return null;

  const CardContent = (
    <div className="rounded-2xl border bg-card text-card-foreground shadow-sm overflow-hidden group transition-all duration-300 hover:shadow-lg hover:-translate-y-1 h-full flex flex-col">
      <div className="relative h-64 w-full overflow-hidden bg-muted/20">
        {imgSrc ? (
          <>
            {!imageLoaded && (
              <div className="absolute inset-0 flex items-center justify-center bg-muted/30">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground/50" />
              </div>
            )}
            <img
              src={imgSrc}
              alt={product.title || product.name || 'Product Image'}
              onLoad={() => setImageLoaded(true)}
              className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${imageLoaded ? 'product-image-loaded' : 'product-image-loading'}`}
              loading="lazy"
            />
          </>
        ) : (
          <div className="product-image-placeholder group-hover:bg-muted/60 flex flex-col items-center justify-center h-full w-full">
            <ImageIcon className="h-12 w-12 mb-3 opacity-40" strokeWidth={1.5} />
            <span className="text-sm font-medium opacity-60 tracking-wide">No Image Available</span>
          </div>
        )}
        
        <div className="absolute inset-0 bg-black/5 group-hover:bg-black/10 transition-all duration-300 pointer-events-none" />
        
        {product.ribbon_text && (
          <div className="absolute top-3 left-3 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full shadow-sm">
            {product.ribbon_text}
          </div>
        )}

        <div className="absolute top-3 right-3 bg-background/95 backdrop-blur-sm text-foreground text-xs font-bold px-3 py-1 rounded-full flex items-baseline gap-1.5 shadow-sm border">
          {hasSale && (
            <span className="line-through opacity-50">{originalPrice}</span>
          )}
          <span>{displayPrice}</span>
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <p className="text-xs text-muted-foreground mb-1 font-semibold uppercase tracking-wider">{displayCategory}</p>
        <h3 className="text-lg font-bold truncate mb-1">{product.title || product.name || 'Untitled Product'}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-grow">{product.subtitle || product.description || 'Premium quality design and comfort.'}</p>
        
        <Button 
          onClick={handleAddToCart} 
          className="w-full mt-auto active:scale-[0.98] transition-transform"
        >
          <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
        </Button>
      </div>
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: Math.min(index * 0.05, 0.5) }}
      className="h-full"
    >
      {product.isPrintful ? (
        <div className="h-full block cursor-default">{CardContent}</div>
      ) : (
        <Link to={`/product/${product.id}`} className="h-full block">
          {CardContent}
        </Link>
      )}
    </motion.div>
  );
};

const ProductsList = ({ products: externalProducts, isLoading }) => {
  const [internalProducts, setInternalProducts] = useState([]);
  const [loading, setLoading] = useState(externalProducts === undefined);
  const [error, setError] = useState(null);

  const baseProducts = externalProducts !== undefined ? externalProducts : internalProducts;
  
  const displayProducts = useMemo(() => {
    return baseProducts.filter(product => !!product.image || !!product.imageUrl);
  }, [baseProducts]);

  useEffect(() => {
    if (externalProducts !== undefined) {
      setLoading(false);
      return;
    }

    const fetchProductsWithQuantities = async () => {
      try {
        setLoading(true);
        setError(null);

        const productsResponse = await getProducts();

        if (!productsResponse.products || productsResponse.products.length === 0) {
          setInternalProducts([]);
          return;
        }

        const productIds = productsResponse.products.map(product => product.id);

        const quantitiesResponse = await getProductQuantities({
          fields: 'inventory_quantity',
          product_ids: productIds
        });

        const variantQuantityMap = new Map();
        if (quantitiesResponse.variants) {
          quantitiesResponse.variants.forEach(variant => {
            variantQuantityMap.set(variant.id, variant.inventory_quantity);
          });
        }

        const productsWithQuantities = productsResponse.products.map(product => ({
          ...product,
          calculated_price_in_cents: product.price_in_cents || 2999,
          variants: (product.variants || []).map(variant => ({
            ...variant,
            inventory_quantity: variantQuantityMap.get(variant.id) ?? variant.inventory_quantity
          }))
        }));

        setInternalProducts(productsWithQuantities);
      } catch (err) {
        setError(err.message || 'Failed to load products');
      } finally {
        setLoading(false);
      }
    };

    fetchProductsWithQuantities();
  }, [externalProducts]);

  const isCurrentlyLoading = isLoading || loading;

  if (isCurrentlyLoading) {
    return (
      <div className="flex flex-col justify-center items-center h-64 space-y-4">
        <Loader2 className="h-10 w-10 text-primary animate-spin" />
        <p className="text-muted-foreground animate-pulse font-medium">Loading products...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center bg-destructive/10 text-destructive rounded-xl p-8 border border-destructive/20">
        <AlertCircle className="h-10 w-10 mx-auto mb-4 opacity-80" />
        <p className="font-medium">Error loading products: {error}</p>
      </div>
    );
  }

  if (!displayProducts || displayProducts.length === 0) {
    return (
      <div className="text-center bg-muted/30 rounded-2xl p-16 border border-border border-dashed">
        <ShoppingCart className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-40" />
        <h3 className="text-xl font-bold mb-2">No products found</h3>
        <p className="text-muted-foreground max-w-md mx-auto">We couldn't find any products matching your current filters. Try adjusting your criteria or clearing filters.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {displayProducts.map((product, index) => (
        <ProductCard 
          key={product.id || `fallback-key-${index}`} 
          product={product} 
          index={index} 
        />
      ))}
    </div>
  );
};

export default ProductsList;
