
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          <div className="lg:col-span-4">
            <span className="text-2xl font-bold" style={{ fontFamily: 'Playfair Display, serif' }}>
              LUXE
            </span>
            <p className="mt-4 text-sm text-secondary-foreground/80">
              Premium fashion for the modern lifestyle. Quality craftsmanship meets timeless design.
            </p>
          </div>

          <div className="lg:col-span-2">
            <h3 className="font-semibold mb-4">Shop</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/shop" className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors">
                  All Products
                </Link>
              </li>
            </ul>
          </div>

          <div className="lg:col-span-3">
            <h3 className="font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/contact" className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link to="/shipping" className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors">
                  Shipping Information
                </Link>
              </li>
              <li>
                <Link to="/returns" className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors">
                  Returns & Exchanges
                </Link>
              </li>
            </ul>
          </div>

          <div className="lg:col-span-3 flex flex-col">
            <h3 className="font-semibold mb-4">Connect With Us</h3>
            <div className="flex space-x-4 mb-4">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="h-5 w-5" />
              </a>
            </div>
            <div className="flex flex-wrap w-full">
              <p className="text-sm text-secondary-foreground/80 whitespace-nowrap">
                Email: <a href="mailto:contact-us@luxefashion.style" className="hover:text-secondary-foreground transition-colors">contact-us@luxefashion.style</a>
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-secondary-foreground/20">
          <div className="flex flex-col md:flex-row justify-between items-center text-sm text-secondary-foreground/80 gap-4">
            <p>&copy; 2026 LUXE Fashion. All rights reserved.</p>
            <div className="flex flex-wrap justify-center gap-6">
              <Link to="/privacy-policy" className="hover:text-secondary-foreground transition-colors whitespace-nowrap">
                Privacy Policy
              </Link>
              <Link to="/terms-of-service" className="hover:text-secondary-foreground transition-colors whitespace-nowrap">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
