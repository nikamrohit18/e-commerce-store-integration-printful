
import React, { useState } from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { ChevronDown, ChevronUp } from 'lucide-react';

const CategoryFilter = ({ onFilterChange, onClearFilters }) => {
  const [expandedSections, setExpandedSections] = useState({
    size: true,
    color: true,
    price: true,
  });

  const [selectedSizes, setSelectedSizes] = useState([]);
  const [selectedColors, setSelectedColors] = useState([]);
  const [priceRange, setPriceRange] = useState([0, 500]);

  const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
  const colors = [
    { name: 'Black', value: 'black', hex: '#000000' },
    { name: 'White', value: 'white', hex: '#FFFFFF' },
    { name: 'Gray', value: 'gray', hex: '#9CA3AF' },
    { name: 'Navy', value: 'navy', hex: '#1E3A8A' },
    { name: 'Beige', value: 'beige', hex: '#D4C5B9' },
    { name: 'Brown', value: 'brown', hex: '#92400E' },
  ];

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const handleSizeChange = (size) => {
    const newSizes = selectedSizes.includes(size)
      ? selectedSizes.filter(s => s !== size)
      : [...selectedSizes, size];
    setSelectedSizes(newSizes);
  };

  const handleColorChange = (color) => {
    const newColors = selectedColors.includes(color)
      ? selectedColors.filter(c => c !== color)
      : [...selectedColors, color];
    setSelectedColors(newColors);
  };

  const handleApplyFilters = () => {
    onFilterChange({
      sizes: selectedSizes,
      colors: selectedColors,
      priceRange,
    });
  };

  const handleClearFilters = () => {
    setSelectedSizes([]);
    setSelectedColors([]);
    setPriceRange([0, 500]);
    onClearFilters();
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-card-foreground">Filters</h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleClearFilters}
          className="text-muted-foreground hover:text-foreground"
        >
          Clear all
        </Button>
      </div>

      <div className="space-y-4">
        <div className="border-b border-border pb-4">
          <button
            onClick={() => toggleSection('size')}
            className="flex items-center justify-between w-full text-left"
          >
            <span className="font-medium text-card-foreground">Size</span>
            {expandedSections.size ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
          {expandedSections.size && (
            <div className="mt-4 space-y-3">
              {sizes.map(size => (
                <div key={size} className="flex items-center space-x-2">
                  <Checkbox
                    id={`size-${size}`}
                    checked={selectedSizes.includes(size)}
                    onCheckedChange={() => handleSizeChange(size)}
                  />
                  <Label
                    htmlFor={`size-${size}`}
                    className="text-sm text-card-foreground cursor-pointer"
                  >
                    {size}
                  </Label>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="border-b border-border pb-4">
          <button
            onClick={() => toggleSection('color')}
            className="flex items-center justify-between w-full text-left"
          >
            <span className="font-medium text-card-foreground">Color</span>
            {expandedSections.color ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
          {expandedSections.color && (
            <div className="mt-4 space-y-3">
              {colors.map(color => (
                <div key={color.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={`color-${color.value}`}
                    checked={selectedColors.includes(color.value)}
                    onCheckedChange={() => handleColorChange(color.value)}
                  />
                  <Label
                    htmlFor={`color-${color.value}`}
                    className="flex items-center space-x-2 text-sm text-card-foreground cursor-pointer"
                  >
                    <span
                      className="w-4 h-4 rounded-full border border-border"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span>{color.name}</span>
                  </Label>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="pb-4">
          <button
            onClick={() => toggleSection('price')}
            className="flex items-center justify-between w-full text-left"
          >
            <span className="font-medium text-card-foreground">Price range</span>
            {expandedSections.price ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </button>
          {expandedSections.price && (
            <div className="mt-4 space-y-4">
              <Slider
                value={priceRange}
                onValueChange={setPriceRange}
                max={500}
                step={10}
                className="w-full"
              />
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      <Button
        onClick={handleApplyFilters}
        className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90"
      >
        Apply filters
      </Button>
    </div>
  );
};

export default CategoryFilter;
